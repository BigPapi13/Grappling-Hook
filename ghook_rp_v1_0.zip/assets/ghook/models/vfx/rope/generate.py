text = """
{
	"credit": "Made with Blockbench",
	"texture_size": [16, 1024],
	"textures": {
		"0": "ghook:vfx/rope",
		"particle": "ghook:vfx/rope"
	},
	"elements": [
		{
			"from": [7.5, 8, 7.5],
			"to": [8.5, 8.0625, 8.5],
			"faces": {
				"north": {"uv": [0, 0, 1, 0.25], "texture": "#0"},
				"east": {"uv": [0, 0, 1, 0.25], "texture": "#0"},
				"south": {"uv": [0, 0, 1, 0.25], "texture": "#0"},
				"west": {"uv": [0, 0, 1, 0.25], "texture": "#0"},
				"up": {"uv": [0, 0, 1, 0.015625], "texture": "#0"},
				"down": {"uv": [0, 0, 1, 0.015625], "texture": "#0"}
			}
		}
	],
	"display": {
		"head": {
			"rotation": [-90, 0, 0],
			"scale": [1, 4, 1]
		}
	}
}
"""

i = 1
while i <= 64:
    f = open(str(i) + ".json",'w')
    f.write(
"""{
	"credit": "Made with Blockbench",
	"texture_size": [16, 1024],
	"textures": {
		"0": "ghook:vfx/rope",
		"particle": "ghook:vfx/rope"
	},
	"elements": [
		{
			"from": [7.9921875, 8, 7.9921875],
			"to": [8.0078125, """ + str(8 + i / 16) + ", 8.0078125]," +
"""
			"faces": {
				"north": {"uv": [0, 0, 1, """ + str(0.25 * i) + """], "rotation": 180, "texture": "#0"},
				"east": {"uv": [0, 0, 1, """ + str(0.25 * i) + """], "rotation": 180, "texture": "#0"},
				"south": {"uv": [0, 0, 1, """ + str(0.25 * i) + """], "rotation": 180, "texture": "#0"},
				"west": {"uv": [0, 0, 1, """ + str(0.25 * i) + """], "rotation": 180, "texture": "#0"},
				"up": {"uv": [0, 0, 1, 0.015625], "texture": "#0"},
				"down": {"uv": [0, 0, 1, 0.015625], "texture": "#0"}
			}
		}
	],
	"display": {
		"head": {
			"rotation": [-90, 0, 0],
			"scale": [1, 4, 1]
		}
	}
}
"""
	)
    
    f.close()
    i += 1
    

i = 1
while i <= 15:
    f = open("micro_" + str(i) + ".json",'w')
    f.write(
"""{
	"credit": "Made with Blockbench",
	"texture_size": [16, 1024],
	"textures": {
		"0": "ghook:vfx/rope",
		"particle": "ghook:vfx/rope"
	},
	"elements": [
		{
			"from": [7.9921875, 8, 7.9921875],
			"to": [8.0078125, """ + str(8 + i / 256) + ", 8.0078125]," +
"""
			"faces": {
				"north": {"uv": [0, 0, 1, """ + str(0.015625 * i) + """], "rotation": 180, "texture": "#0"},
				"east": {"uv": [0, 0, 1, """ + str(0.015625 * i) + """], "rotation": 180, "texture": "#0"},
				"south": {"uv": [0, 0, 1, """ + str(0.015625 * i) + """], "rotation": 180, "texture": "#0"},
				"west": {"uv": [0, 0, 1, """ + str(0.015625 * i) + """], "rotation": 180, "texture": "#0"},
				"up": {"uv": [0, 0, 1, 0.015625], "texture": "#0"},
				"down": {"uv": [0, 0, 1, 0.015625], "texture": "#0"}
			}
		}
	],
	"display": {
		"head": {
			"rotation": [90, 0, 0],
			"scale": [1, 4, 1]
		}
	}
}
"""
	)
    
    f.close()
    i += 1

input("Program complete. Press enter to continue")